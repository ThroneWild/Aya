import Link from "next/link";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur border-b border-neutral-100">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="font-semibold">AYA</Link>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <a href="#beneficios" className="hover:text-neutral-600">Benefícios</a>
          <a href="#como-funciona" className="hover:text-neutral-600">Como funciona</a>
          <a href="#contato" className="hover:text-neutral-600">Contato</a>
          <Link href="/login" className="hover:text-neutral-600">Área do cliente</Link>
        </nav>
        <a href="#contato" className="rounded-xl px-4 py-2 bg-black text-white text-sm hover:opacity-90">Agendar demo</a>
      </div>
    </header>
  );
}
