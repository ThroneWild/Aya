"use client";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import MagneticButton from "./MagneticButton";

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yTitle = useTransform(scrollYProgress, [0, 1], [0, -40]);
  const ySub   = useTransform(scrollYProgress, [0, 1], [0, -20]);

  return (
    <section ref={ref} className="relative overflow-hidden">
      <div className="pointer-events-none absolute -top-10 -left-10 w-80 h-80 rounded-full blur-3xl"
           style={{ background: "radial-gradient(circle at 30% 30%, rgba(251,146,60,.6), rgba(234,88,12,.18) 45%, transparent 70%)" }} />
      <div className="pointer-events-none absolute top-10 right-10 w-96 h-96 rounded-full blur-3xl"
           style={{ background: "radial-gradient(circle at 30% 30%, rgba(234,88,12,.5), rgba(251,146,60,.18) 45%, transparent 70%)" }} />

      <div className="max-w-6xl mx-auto px-4 py-20 md:py-28">
        <div className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs text-white tag">
          AYA • Agentes de IA autônomos
        </div>

        <motion.h1
          className="mt-4 text-4xl md:text-6xl font-semibold tracking-tight max-w-3xl"
          initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}
          style={{ y: yTitle }}
        >
          Agentes de IA que <span className="bg-gradient-to-r from-aya1 to-aya2 bg-clip-text text-transparent">atendem, vendem e aprendem</span>.
        </motion.h1>

        <motion.p
          className="mt-6 text-lg text-neutral-600 max-w-2xl"
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.6 }}
          style={{ y: ySub }}
        >
          O futuro é agora — e ele começa na AYA. Automatize atendimento, qualifique leads e feche mais negócios com um agente de IA treinado no seu playbook.
        </motion.p>

        <motion.div
          className="mt-10 flex flex-wrap gap-3"
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.5 }}
        >
          <a href="#beneficios" className="rounded-2xl px-5 py-3 ring-1 ring-black/10 hover:bg-black/5">
            Ver benefícios
          </a>
          <MagneticButton onClick={() => document.querySelector("#contato")?.scrollIntoView({ behavior: "smooth" })}>
            Agendar demonstração
          </MagneticButton>
        </motion.div>
      </div>
    </section>
  );
}
