"use client";
import { motion } from "framer-motion";
const card = { hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0 } };

export default function HowItWorks() {
  const steps = [
    ["1. Diagnóstico","Entendemos seu processo e suas integrações."],
    ["2. Implementação","Treinamos o agente e conectamos seus canais."],
    ["3. Otimização","Medimos, iteramos e escalamos performance."]
  ];
  return (
    <section id="como-funciona" className="border-t border-neutral-100 bg-neutral-50">
      <div className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-2xl md:text-3xl font-semibold">Como funciona</h2>
        <motion.div
          className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6"
          initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.3 }}
          transition={{ staggerChildren: 0.08 }}
        >
          {steps.map(([title, sub], i) => (
            <motion.div key={i} variants={card} transition={{ duration: 0.45, ease: "easeOut" }}
              className="rounded-2xl border p-6 bg-white">
              <div className="text-sm font-semibold text-neutral-700">{title}</div>
              <p className="mt-2 text-sm text-neutral-600">{sub}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
