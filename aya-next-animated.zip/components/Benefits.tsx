"use client";
import { motion } from "framer-motion";
const card = { hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0 } };

export default function Benefits() {
  const items = [
    ["Atendimento 24/7","Respostas imediatas por WhatsApp, site e redes."],
    ["Qualificação automática","Score e passagem limpa pro funil."],
    ["Integração total","n8n, CRM, planilhas e e-mail — tudo orquestrado."]
  ];
  return (
    <section id="beneficios" className="border-t border-neutral-100">
      <div className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-2xl md:text-3xl font-semibold">Por que a AYA?</h2>
        <motion.div
          className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6"
          initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.3 }}
          transition={{ staggerChildren: 0.08 }}
        >
          {items.map(([title, sub], i) => (
            <motion.div key={i} variants={card} transition={{ duration: 0.45, ease: "easeOut" }}
              className="rounded-2xl border p-6 bg-white shadow-sm">
              <div className="text-sm font-medium">{title}</div>
              <p className="mt-2 text-sm text-neutral-600">{sub}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
