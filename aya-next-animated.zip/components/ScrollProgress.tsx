"use client";
import { motion, useScroll } from "framer-motion";
export default function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-[3px] z-[60] bg-gradient-to-r from-aya1 to-aya2 origin-left"
      style={{ scaleX: scrollYProgress }}
    />
  );
}
