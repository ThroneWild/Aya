"use client";
import { useState } from "react";

export default function Contact() {
  const [method, setMethod] = useState<'api' | 'webhook'>('api');

  return (
    <section id="contato" className="border-t border-neutral-100">
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="max-w-2xl">
          <h2 className="text-2xl md:text-3xl font-semibold">Vamos conversar</h2>
          <p className="mt-2 text-neutral-600">Preencha e a gente agenda uma demo. Resposta rápida.</p>
        </div>

        <div className="mt-6 text-xs text-neutral-500 flex gap-3">
          <button onClick={() => setMethod('webhook')} className={`px-3 py-1 rounded-lg ring-1 ${method==='webhook'?'bg-black text-white ring-black':'ring-black/10 hover:bg-black/5'}`}>Enviar via Webhook</button>
          <button onClick={() => setMethod('api')} className={`px-3 py-1 rounded-lg ring-1 ${method==='api'?'bg-black text-white ring-black':'ring-black/10 hover:bg-black/5'}`}>Enviar via /api/lead</button>
        </div>

        {method === 'webhook' ? (
          <form className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4" action="__N8N_WEBHOOK_URL__" method="post">
            <input className="rounded-xl border p-3" name="name" placeholder="Seu nome" required />
            <input className="rounded-xl border p-3" type="email" name="email" placeholder="Seu e-mail" required />
            <input className="rounded-xl border p-3 md:col-span-2" name="company" placeholder="Empresa (opcional)" />
            <input className="rounded-xl border p-3 md:col-span-2" name="phone" placeholder="WhatsApp (opcional)" />
            <textarea className="rounded-xl border p-3 md:col-span-2" name="challenge" rows={4} placeholder="Qual seu principal desafio hoje?"></textarea>
            <div className="md:col-span-2 flex items-center gap-3">
              <button type="submit" className="rounded-2xl px-5 py-3 bg-black text-white hover:opacity-90">Enviar</button>
              <span className="text-xs text-neutral-500">Ao enviar, você concorda com nosso contato.</span>
            </div>
          </form>
        ) : (
          <form className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4" onSubmit={async (e) => {
            e.preventDefault();
            const data = Object.fromEntries(new FormData(e.currentTarget).entries());
            const res = await fetch('/api/lead', { method: 'POST', headers: { 'content-type':'application/json' }, body: JSON.stringify(data) });
            alert(res.ok ? 'Recebido!' : 'Falhou');
          }}>
            <input className="rounded-xl border p-3" name="name" placeholder="Seu nome" required />
            <input className="rounded-xl border p-3" type="email" name="email" placeholder="Seu e-mail" required />
            <input className="rounded-xl border p-3 md:col-span-2" name="company" placeholder="Empresa (opcional)" />
            <input className="rounded-xl border p-3 md:col-span-2" name="phone" placeholder="WhatsApp (opcional)" />
            <textarea className="rounded-xl border p-3 md:col-span-2" name="challenge" rows={4} placeholder="Qual seu principal desafio hoje?"></textarea>
            <div className="md:col-span-2 flex items-center gap-3">
              <button type="submit" className="rounded-2xl px-5 py-3 bg-black text-white hover:opacity-90">Enviar</button>
              <span className="text-xs text-neutral-500">Ao enviar, você concorda com nosso contato.</span>
            </div>
          </form>
        )}
      </div>
    </section>
  );
}
