"use client";
import { useRef } from "react";

export default function MagneticButton(
  { children, className = "", ...props }:
  React.ButtonHTMLAttributes<HTMLButtonElement> & { children: React.ReactNode }
) {
  const ref = useRef<HTMLButtonElement>(null);
  function onMove(e: React.MouseEvent<HTMLButtonElement>) {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - (r.left + r.width/2)) * 0.15;
    const y = (e.clientY - (r.top + r.height/2)) * 0.15;
    el.style.transform = `translate(${x}px, ${y}px)`;
  }
  function onLeave() { const el = ref.current; if (!el) return; el.style.transform = "translate(0,0)"; }
  return (
    <button
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className={`rounded-2xl px-5 py-3 bg-black text-white hover:opacity-90 will-change-transform ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
