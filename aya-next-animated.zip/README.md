# AYA — Next.js Animated Starter

Pronto para StackBlitz (preview lado a lado), Render/Vercel/Railway (com /api), e Hostinger (export estático).

## Rodar
```bash
npm i
npm run dev
```

## Animações inclusas
- **Parallax** no Hero (`useScroll` + `useTransform`)
- **CTA Magnético** que segue o mouse
- **Reveals com stagger** ao entrar na tela
- **Barra de progresso** de scroll no topo

## Envio de Lead
- **/api/lead** (quando rodando com backend): configure `N8N_WEBHOOK_NEW_LEAD` no ambiente.
- **Webhook direto (HTML)**: em `components/Contact.tsx`, mude para "webhook" e edite `action="__N8N_WEBHOOK_URL__"`.
- Para export estático: `npm run export` → `out/` → suba para Hostinger.

Bom trabalho!
