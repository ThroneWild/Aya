/** @type {import('next').NextConfig} */
const isStatic = process.env.STATIC_EXPORT === 'true';
const nextConfig = {
  experimental: { typedRoutes: true },
  images: { unoptimized: isStatic },
  output: isStatic ? 'export' : undefined
};
export default nextConfig;
