import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { name, email, company, phone, challenge } = body || {};
  if (!name || !email) {
    return NextResponse.json({ ok: false, error: "Missing fields" }, { status: 400 });
  }
  if (process.env.N8N_WEBHOOK_NEW_LEAD) {
    try {
      await fetch(process.env.N8N_WEBHOOK_NEW_LEAD, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ event: "new_lead", name, email, company, phone, challenge, source: "site-aya" })
      });
    } catch {}
  }
  return NextResponse.json({ ok: true });
}
