export default function Login() {
  return (
    <main className="min-h-screen grid place-items-center bg-neutral-50 text-neutral-900">
      <div className="w-full max-w-md bg-white border rounded-2xl shadow-sm p-6">
        <h1 className="text-xl font-semibold">Área do Cliente</h1>
        <p className="mt-2 text-sm text-neutral-600">Em breve: login por Magic Link.</p>
        <form className="mt-6 space-y-3" action="__YOUR_MAGIC_LINK_ENDPOINT__" method="post">
          <input className="w-full rounded-xl border p-3" type="email" name="email" placeholder="Seu e-mail" required />
          <button className="w-full rounded-xl px-4 py-2 bg-black text-white hover:opacity-90" type="submit">Enviar Magic Link</button>
        </form>
      </div>
    </main>
  );
}
