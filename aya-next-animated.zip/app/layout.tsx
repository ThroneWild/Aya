import "./../styles/globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "AYA — Agentes de IA que atendem, vendem e aprendem",
  description: "O futuro é agora — e ele começa na AYA."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
