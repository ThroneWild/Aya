import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Benefits from "@/components/Benefits";
import HowItWorks from "@/components/HowItWorks";
import Contact from "@/components/Contact";
import ScrollProgress from "@/components/ScrollProgress";

export default function Page() {
  return (
    <>
      <Navbar />
      <ScrollProgress />
      <main>
        <Hero />
        <Benefits />
        <HowItWorks />
        <Contact />
      </main>
      <footer className="border-t border-neutral-100">
        <div className="max-w-6xl mx-auto px-4 py-10 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-neutral-500">
          <div>© {new Date().getFullYear()} AYA. O futuro é agora.</div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-neutral-700">Privacidade</a>
            <a href="#" className="hover:text-neutral-700">Termos</a>
          </div>
        </div>
      </footer>
    </>
  );
}
