export default function Dashboard() {
  const stages = ["Novo","Qualificado","Agendado","Proposta","Fechado"];
  const mock = [
    { id: "1", name:"Maria Silva", company:"Clínica Mova", stage:"Novo" },
    { id: "2", name:"João Neto", company:"Pousada Rio", stage:"Qualificado" }
  ];
  return (
    <main className="p-4 max-w-7xl mx-auto">
      <h1 className="text-2xl font-semibold">Funil</h1>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mt-6">
        {stages.map(s => (
          <div key={s} className="rounded-2xl bg-neutral-50 border p-3">
            <div className="font-medium mb-2">{s}</div>
            <div className="space-y-2 min-h-24">
              {mock.filter(l => l.stage===s).map(l => (
                <div key={l.id} className="rounded-xl bg-white border p-3 shadow-soft">
                  <div className="text-sm font-semibold">{l.name}</div>
                  <div className="text-xs text-neutral-500">{l.company || "—"}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
